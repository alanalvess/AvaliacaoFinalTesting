package com.dh.avaliacaofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoFinalApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
