package com.dh.avaliacaofinal.backendTest;

public class Cookies {

    protected static Object JSESSIONID = "JSESSIONID=4FBCDD9F6F97717011B4402EB47587B8";

}
